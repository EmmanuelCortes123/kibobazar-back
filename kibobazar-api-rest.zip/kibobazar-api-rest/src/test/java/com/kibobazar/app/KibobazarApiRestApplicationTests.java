package com.kibobazar.app;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KibobazarApiRestApplicationTests {

	@Test
	void contextLoads() {
	}

}
